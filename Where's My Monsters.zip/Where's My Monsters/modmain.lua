

        Assets = 
{
        Asset( "IMAGE", "minimap/moose.tex" ),
        Asset( "ATLAS", "minimap/moose.xml" ),	
        Asset( "IMAGE", "minimap/bearger.tex" ),
        Asset( "ATLAS", "minimap/bearger.xml" ),
        Asset( "IMAGE", "minimap/dragonfly.tex" ),
        Asset( "ATLAS", "minimap/dragonfly.xml" ),
        Asset( "IMAGE", "minimap/deerclops.tex" ),
        Asset( "ATLAS", "minimap/deerclops.xml" ),
        Asset( "IMAGE", "minimap/leif.tex" ),
        Asset( "ATLAS", "minimap/leif.xml" ),
        Asset( "IMAGE", "minimap/spiderqueen.tex" ),
        Asset( "ATLAS", "minimap/spiderqueen.xml" ),
	Asset( "IMAGE", "minimap/rocky.tex" ),
        Asset( "ATLAS", "minimap/rocky.xml" ),
	Asset( "IMAGE", "minimap/babybeefalo.tex" ),
        Asset( "ATLAS", "minimap/babybeefalo.xml" ),
        Asset( "IMAGE", "minimap/beefalo.tex" ),
        Asset( "ATLAS", "minimap/beefalo.xml" ),
	Asset( "IMAGE", "minimap/lightninggoat.tex" ),
        Asset( "ATLAS", "minimap/lightninggoat.xml" ),
        Asset( "IMAGE", "minimap/mandrake.tex" ),
        Asset( "ATLAS", "minimap/mandrake.xml" ),
	Asset( "IMAGE", "minimap/warg.tex" ),
        Asset( "ATLAS", "minimap/warg.xml" ),
	Asset( "IMAGE", "minimap/krampus.tex" ),
        Asset( "ATLAS", "minimap/krampus.xml" ),
        Asset( "IMAGE", "minimap/minotaur.tex" ),
        Asset( "ATLAS", "minimap/minotaur.xml" ),
	Asset( "IMAGE", "minimap/tentacle.tex" ),
        Asset( "ATLAS", "minimap/tentacle.xml" ),
	Asset( "IMAGE", "minimap/worm.tex" ),
        Asset( "ATLAS", "minimap/worm.xml" ),
	Asset( "IMAGE", "minimap/wall_hay.tex" ),
        Asset( "ATLAS", "minimap/wall_hay.xml" ),
	Asset( "IMAGE", "minimap/wall_wood.tex" ),
        Asset( "ATLAS", "minimap/wall_wood.xml" ),
	Asset( "IMAGE", "minimap/wall_stone.tex" ),
        Asset( "ATLAS", "minimap/wall_stone.xml" ),
}

function AddMap(inst)
        local minimap = inst.entity:AddMiniMapEntity()
        minimap:SetIcon( inst.prefab .. ".tex" )
end

AddPrefabPostInit("moose", AddMap)
AddPrefabPostInit("bearger", AddMap)
AddPrefabPostInit("dragonfly", AddMap)
AddPrefabPostInit("deerclops", AddMap)
AddPrefabPostInit("leif", AddMap)
AddPrefabPostInit("spiderqueen", AddMap)
AddPrefabPostInit("rocky", AddMap)
AddPrefabPostInit("babybeefalo", AddMap)
AddPrefabPostInit("beefalo", AddMap)
AddPrefabPostInit("lightninggoat", AddMap)
AddPrefabPostInit("mandrake", AddMap)
AddPrefabPostInit("warg", AddMap)
AddPrefabPostInit("krampus", AddMap)
AddPrefabPostInit("minotaur", AddMap)
AddPrefabPostInit("tentacle", AddMap)
AddPrefabPostInit("worm", AddMap)
AddPrefabPostInit("wall_hay", AddMap)
AddPrefabPostInit("wall_wood", AddMap)
AddPrefabPostInit("wall_stone", AddMap)

AddMinimapAtlas("minimap/moose.xml")
AddMinimapAtlas("minimap/bearger.xml")
AddMinimapAtlas("minimap/dragonfly.xml")
AddMinimapAtlas("minimap/deerclops.xml")
AddMinimapAtlas("minimap/leif.xml")
AddMinimapAtlas("minimap/spiderqueen.xml")
AddMinimapAtlas("minimap/rocky.xml")
AddMinimapAtlas("minimap/babybeefalo.xml")
AddMinimapAtlas("minimap/beefalo.xml")
AddMinimapAtlas("minimap/lightninggoat.xml")
AddMinimapAtlas("minimap/mandrake.xml")
AddMinimapAtlas("minimap/warg.xml")
AddMinimapAtlas("minimap/krampus.xml")
AddMinimapAtlas("minimap/minotaur.xml")
AddMinimapAtlas("minimap/tentacle.xml")
AddMinimapAtlas("minimap/worm.xml")
AddMinimapAtlas("minimap/wall_hay.xml")
AddMinimapAtlas("minimap/wall_wood.xml")
AddMinimapAtlas("minimap/wall_stone.xml")