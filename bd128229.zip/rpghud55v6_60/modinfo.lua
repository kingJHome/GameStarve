name = "RPG HUD"
description = "Amulet & Backpack slots".."\n".."55 Inventory slots".."\n".."Bigger Backpacks and Containers".."\n" 
author = "Kiopho"
version = "6.60"
forumthread = "17842-Download-The-RPG-Experience"
api_version = 4
icon_atlas = "modicon.xml"
icon = "modicon.tex"