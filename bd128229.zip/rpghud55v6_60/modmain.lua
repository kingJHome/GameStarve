-- V6.60 Bugfix : no more crashes when trying to revive to a resurrection stone
-- V6.50 Bugfix : no more crashes after dying
-- V6.40 Bugfixes : the status values won't disappear (Neat) - the red amulet revives again
-- V6.30 All's Well That Maxwell update
-- V6.20 Inventorybar fix
-- V6.10 Backpack fix
-- V6.00 Six Feet Under update
-- V5.00 A Moderately Friendly update
-- V4.00 The Stuff of Nightmares update
-- V3.20 Proper WX78 upgrade animations when using the Neat versions
-- V3.10 Hungry for your hunger update
-- V3.02 No more incompatibilities with Display Food Values
-- V3.01 WX78 bugfix, fixed some wrong tex/anim files
-- V3.00 Strange New Powers update
-- V2.20 Added naughtiness tab
-- V2.10 Added background color to the containers slots
-- V2.03 Bugfix : the game won't crash if you use the shortcut for the backpack while not equipped
-- V2.02 Bugfix : if you are resurrected with the amulet you'll end up losing it like originally intended
-- V2.01 Bugfix : the game won't crash anymore when you downgrade to a smaller inventory version
-- V2.00 Underground - added shortcuts for the crafting tab (R) and the backpack (B) + cosmetic change to the crafting tab
-- V1.20 Increased the zoom out without the game making you go back to the default zoom
-- V1.10 Increased the size of the backpacks
-- V1.00 Realease version

-- Mod created By Kiopho
--------------------------------------------------------------------------------------------------------------------------

Assets = {
	Asset("ATLAS", "images/equipslots.xml"),
	Asset("ATLAS", "images/container.xml"),
	Asset("ATLAS", "images/inv_slot_spoiled.xml"),
	Asset("ATLAS", "images/inventory_bg55.xml"),
	Asset("ATLAS", "images/krampus_sack_bg.xml"),
}

Vector3 = GLOBAL.Vector3

--------------------------------------------------------------------------------------------------------------------------

-- Do not change
local function inventorypostinit(component,inst)
	inst.components.inventory.maxslots = 55
	inst.components.inventory.numequipslots = 5
end

AddComponentPostInit("inventory", inventorypostinit)
--

-- Making the spoiling food not cover the slots background
local function ItemTilePostInit(self, invitem)
	self.bg:SetTexture("images/inv_slot_spoiled.xml", "inv_slot_spoiled.tex")
end

AddClassPostConstruct("widgets/itemtile", ItemTilePostInit)
--

-- Custom slot background color
local function TintingPostInit(self, num, atlas, bgim, owner, container)
	if container.widgetbgimagetint then
		self.bgimage:SetTint(container.widgetbgimagetint.r, container.widgetbgimagetint.g, container.widgetbgimagetint.b, container.widgetbgimagetint.a)
    end
end

AddClassPostConstruct("widgets/invslot", TintingPostInit)
--

-- Krampus sack
local function krampussackpostinit(inst)
	local slotpos = {}
	
	for y = 0, 9 do
	table.insert(slotpos, Vector3(-37, -y*75 + 338 ,0))
	table.insert(slotpos, Vector3(-37 +75, -y*75 + 338 ,0))
	end
	
	inst.components.container.numslots = #slotpos
	inst.components.container.widgetslotpos = slotpos
	inst.components.container.widgetanimbank = nil
	inst.components.container.widgetanimbuild = nil
	inst.components.container.widgetbgatlas = "images/krampus_sack_bg.xml"
	inst.components.container.widgetbgimage = "krampus_sack_bg.tex"
	inst.components.container.widgetpos = Vector3(-76,-57,0)
	
	inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.PACK
	inst.components.inventoryitem.cangoincontainer = true
	inst:AddTag("nonpotatable")
end

AddPrefabPostInit("krampus_sack", krampussackpostinit)
--

-- Piggyback
local function piggybackpostinit(inst)
	local slotpos = {}
	
	for y = 0, 6 do
	table.insert(slotpos, Vector3(-162, -y*75 + 240 ,0))
	table.insert(slotpos, Vector3(-162 +75, -y*75 + 240 ,0))
	end

	inst.components.container.numslots = #slotpos
	inst.components.container.widgetslotpos = slotpos
	inst.components.container.widgetanimbank = "ui_krampusbag_2x8"
	inst.components.container.widgetanimbuild = "ui_krampusbag_2x8"
	inst.components.container.widgetpos = Vector3(0,-75,0)

	inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.PACK
	inst.components.inventoryitem.cangoincontainer = true
	inst.components.equippable.walkspeedmult = 1
	inst:AddTag("nonpotatable")
end

AddPrefabPostInit("piggyback", piggybackpostinit)
--

-- Backpack
local function backpackpostinit(inst)
	local slotpos = {}

	for y = 0, 4 do
	table.insert(slotpos, Vector3(-162, -y*75 + 112 ,0))
	table.insert(slotpos, Vector3(-162 +75, -y*75 + 112 ,0))
	end
	
	inst.components.container.numslots = #slotpos
	inst.components.container.widgetslotpos = slotpos
	inst.components.container.widgetanimbank = "ui_krampusbag_2x5"
	inst.components.container.widgetanimbuild = "ui_krampusbag_2x5"
	inst.components.container.widgetpos = Vector3(0,-50,0)
	
	inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.PACK
	inst.components.inventoryitem.cangoincontainer = true
	inst:AddTag("nonpotatable")
end

AddPrefabPostInit("backpack", backpackpostinit)
--

-- Defines backpack slot
table.insert(GLOBAL.EQUIPSLOTS, "PACK")
GLOBAL.EQUIPSLOTS.PACK = "pack"
--

-- Chester
local function chesterpostinit(inst)
	local slotpos = {}

    for y = 3, 0, -1 do
		for x = 0, 3 do
		table.insert(slotpos, Vector3(80*x-80*2+40, 80*y-80*2+40,0))
		end
	end

	inst.components.container.widgetanimbank = nil
	inst.components.container.widgetanimbuild = nil
	inst.components.container.widgetbgatlas = "images/container.xml"
	inst.components.container.widgetbgimage = "container.tex"
	inst.components.container.widgetpos = Vector3(0,-200,0)
	inst.components.container.numslots = #slotpos
	inst.components.container.widgetslotpos = slotpos
	inst.components.container.widgetbgimagetint = {r=.75,g=.58,b=.44,a=1}
end

AddPrefabPostInit("chester", chesterpostinit)
--

-- Chests
local function treasurechestpostinit(inst)
	local slotpos = {}

	for y = 3, 0, -1 do
		for x = 0, 3 do
		table.insert(slotpos, Vector3(80*x-80*2+40, 80*y-80*2+40,0))
		end
	end

	inst.components.container.widgetanimbank = nil
	inst.components.container.widgetanimbuild = nil
	inst.components.container.widgetbgatlas = "images/container.xml"
	inst.components.container.widgetbgimage = "container.tex"
	inst.components.container.numslots = #slotpos
	inst.components.container.widgetslotpos = slotpos
	inst.components.container.widgetbgimagetint = {r=.82,g=.77,b=.7,a=1}
end

AddPrefabPostInit("treasurechest", treasurechestpostinit)
--

-- Ice Box
local function iceboxpostinit(inst)
	local slotpos = {}

	for y = 3, 0, -1 do
		for x = 0, 3 do
			table.insert(slotpos, Vector3(80*x-80*2+40, 80*y-80*2+40,0))
		end
	end

	inst.components.container.widgetanimbank = nil
	inst.components.container.widgetanimbuild = nil
	inst.components.container.widgetbgatlas = "images/container.xml"
	inst.components.container.widgetbgimage = "container.tex"
	inst.components.container.numslots = #slotpos
	inst.components.container.widgetslotpos = slotpos
	inst.components.container.widgetbgimagetint = {r=.44,g=.74,b=1,a=1}
end

AddPrefabPostInit("icebox", iceboxpostinit)
--

-- Crock Pot
local function crockpotpostinit(inst)
	inst.components.container.widgetbgimagetint = {r=1,g=.42,b=.33,a=1}
end

AddPrefabPostInit("cookpot", crockpotpostinit)
--

-- Amulets
local function amuletpostinit(inst)
	inst.components.equippable.equipslot = GLOBAL.EQUIPSLOTS.NECK
end

AddPrefabPostInit("amulet", amuletpostinit)
AddPrefabPostInit("blueamulet", amuletpostinit)
AddPrefabPostInit("purpleamulet", amuletpostinit)
AddPrefabPostInit("orangeamulet", amuletpostinit)
AddPrefabPostInit("greenamulet", amuletpostinit)
AddPrefabPostInit("yellowamulet", amuletpostinit)
--

-- Defines amulet slot
table.insert(GLOBAL.EQUIPSLOTS, "NECK")
GLOBAL.EQUIPSLOTS.NECK = "neck"
--

-- Cosmetic stuff : Buttons
local function Buttons(self)
	self.pauseBtn:Kill()
	self.minimapBtn:Kill()
	self.rotleft:Kill()
	self.rotright:Kill()
end

AddClassPostConstruct("widgets/mapcontrols", Buttons)
--

-- Cosmetic stuff : Craft tabs
local function CTabs(self)

	local oldSetOrientation = self.SetOrientation
	
	function self:SetOrientation(horizontal)
	
		oldSetOrientation(self, horizontal)
	
		local slot_w, slot_h = self.bg:GetSlotSize()
		local but_w, but_h = self.downbutton:GetSize()
	
		if horizontal then
			self.downbutton:SetRotation(90)
			self.downbutton:SetPosition(-self.bg.length/2 - but_w/2 + slot_w/2 +40,0,0)
			self.upbutton:SetRotation(-90)
			self.upbutton:SetPosition(self.bg.length/2 + but_w/2 - slot_w/2 - 40,0,0)
		else
			self.upbutton:SetPosition(0, - self.bg.length/2 - but_h/2 + slot_h/2 + 40,0)
			self.downbutton:SetScale(Vector3(1, -1, 1))
			self.downbutton:SetPosition(0, self.bg.length/2 + but_h/2 - slot_h/2 - 40,0)
		end
	end

end

AddClassPostConstruct("widgets/crafting", CTabs)
--

-- Do not change : makes the amulet resurrect
local function resurrectableinit(inst)

	inst.FindClosestResurrector = function(self)
		local res = nil
		if self.inst.components.inventory then
			local item = self.inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
			if item and item.prefab == "amulet" then
				return item
			end
		end

		local Ents = GLOBAL.Ents
		local closest_dist = 0
		for k,v in pairs(Ents) do
			if v.components.resurrector and v.components.resurrector:CanBeUsed() then
				local dist = v:GetDistanceSqToInst(self.inst)
				if not res or dist < closest_dist then
					res = v
					closest_dist = dist
				end
			end
		end

		return res
	end

	inst.CanResurrect = function(self)
		if self.inst.components.inventory then
			local item = self.inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
			if item and item.prefab == "amulet" then
				return true
			end
		end

		local SaveGameIndex = GLOBAL.SaveGameIndex
		local res = false

		if SaveGameIndex:CanUseExternalResurector() then
			res = SaveGameIndex:GetResurrector() 
		end

		if res == nil or res == false then
			res = self:FindClosestResurrector()
		end

		if res then
			return true
		end

		return false
	end

	inst.DoResurrect = function(self)
		self.inst:PushEvent("resurrect")
		if self.inst.components.inventory then
			local item = self.inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
			if item and item.prefab == "amulet" then
				self.inst.sg:GoToState("amulet_rebirth")
				return true
			end
		end
		
		local res = self:FindClosestResurrector()
		if res and res.components.resurrector then
			res.components.resurrector:Resurrect(self.inst)
			return true
		end

		return false
	end

end

AddComponentPostInit("resurrectable", resurrectableinit)
--

-- Do not change : removes the amulet when you die with it equipped
local function newOnExit(inst)

	inst.components.hunger:SetPercent(2/3)
	inst.components.health:Respawn(TUNING.RESURRECT_HEALTH)
	
	if inst.components.sanity then
		inst.components.sanity:SetPercent(.5)
	end
	
	local item = inst.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.NECK)
	if item and item.prefab == "amulet" then
		item = inst.components.inventory:RemoveItem(item)
		if item then
			item:Remove()
			item.persists = false
		end
	end
	--SaveGameIndex:SaveCurrent()
	inst.HUD:Show()
	GLOBAL.TheCamera:SetDefault()
	inst.components.playercontroller:Enable(true)
	inst.AnimState:ClearOverrideSymbol("FX")

end

local function SGWilsonPostInit(sg)
	sg.states["amulet_rebirth"].onexit = newOnExit
end

AddStategraphPostInit("wilson", SGWilsonPostInit)
--

-- Shortcuts
GLOBAL.TheInput:AddKeyDownHandler(GLOBAL.KEY_B, function()
	local TheInput = GLOBAL.TheInput
	local player = GLOBAL.GetPlayer()
	local backpackslot = player.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.PACK)
	
	if not TheInput:IsKeyDown(GLOBAL.KEY_CTRL) and not TheInput:IsKeyDown(GLOBAL.KEY_SHIFT) and not TheInput:IsKeyDown(GLOBAL.KEY_ALT) then
		if backpackslot and backpackslot.components.container then
			if backpackslot.components.container.open then
				backpackslot.components.container:Close()
			else
				backpackslot.components.container:Open(player)
			end
		end
	end
end)

GLOBAL.TheInput:AddKeyDownHandler(GLOBAL.KEY_R, function()
	local controls = GLOBAL.GetPlayer().HUD.controls
	local TheInput = GLOBAL.TheInput
	
	if not TheInput:IsKeyDown(GLOBAL.KEY_CTRL) and not TheInput:IsKeyDown(GLOBAL.KEY_SHIFT) and not TheInput:IsKeyDown(GLOBAL.KEY_ALT) then
		if controls.left_root.shown then
				controls.left_root:Hide()
			else
				controls.left_root:Show()
			end	
	end
end)
--

-- Enabling the backpack to auto-open on load
 local function OpenBackpack(self) 
	
	local oldSetMainCharacter = self.SetMainCharacter

	function self:SetMainCharacter(maincharacter)
		
		oldSetMainCharacter(self, maincharacter)
        
		local bp = maincharacter.components.inventory:GetEquippedItem(GLOBAL.EQUIPSLOTS.PACK)
		
		if bp and bp.components.container then
			bp.components.container:Close()
			bp.components.container:Open(maincharacter)
		end
	end
	
end

AddClassPostConstruct("screens/playerhud", OpenBackpack)
--

-- New Zoom Mecanics
local function Zoom(self)
	
	function self:UpdateClouds(dt)
	
		if not GLOBAL.GetWorld():IsCave() then

			local TheCamera = GLOBAL.TheCamera
			local TheMixer = GLOBAL.TheMixer
			local easing = GLOBAL.require("easing")

			if TheCamera and TheCamera.distance and not TheCamera.dollyzoom then
		
				local dist_percent = (TheCamera.distance - TheCamera.mindist) / (TheCamera.maxdist - TheCamera.mindist)
				local cutoff = .6
				if dist_percent > cutoff then
					if not self.clouds_on then
						TheCamera.should_push_down = false
						self.clouds_on = true
						self.clouds:Show()
						--self.owner.SoundEmitter:PlaySound("dontstarve/common/clouds", "windsound")
						--TheMixer:PushMix("high")
					end
	            
					local p = easing.outCubic( dist_percent-cutoff , 0, 1, 1 - cutoff) 
					--self.clouds:GetAnimState():SetMultColour(1,1,1, p )
					--self.owner.SoundEmitter:SetVolume("windsound",p)
				else
					if self.clouds_on then
						TheCamera.should_push_down = false
						self.clouds_on = false
						self.clouds:Hide()
						--self.owner.SoundEmitter:KillSound("windsound")
						TheMixer:PopMix("high")
					end
				end
			end
		end
	end
end

AddClassPostConstruct ("screens/playerhud", Zoom)
--

-- Always on Status Display Fix
local function StatusDisplayFix(self)
	function self:CloseControllerInventory()
		TheFrontEnd:GetSound():PlaySound("dontstarve/HUD/craft_close")
		self.controls:ShowStatusNumbers()
		self.controls.inv:CloseControllerInventory()
	end
end

for _, moddir in ipairs(GLOBAL.KnownModIndex:GetModsToLoad()) do
    if GLOBAL.KnownModIndex:GetModInfo(moddir).name == "Always On Status" then
        AddClassPostConstruct("screens/playerhud", StatusDisplayFix)
    end
end
--